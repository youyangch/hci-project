'use strict'
// Object.defineProperty(exports, '__esModule', { value: true })
// eslint-disable-next-line
var colors_1 = require('@ant-design/colors')
// All antd theme variables: https://github.com/ant-design/ant-design/blob/master/components/style/themes/default.less
module.exports = {
  '@header-index-right-bg': '#000', // '#ffffff',
  '@custom-text-color': '#ffffff',
  '@custom-dropdown-bg': 'rgba(61,93,119, 1)', // 下拉菜单
  '@custom-modal-bg': 'linear-gradient(160deg, #3D5D77  20%,#727080 80%)', // 'rgba(40, 75, 104, 1)',7A96A0//弹窗背景
  '@custom-drawer-bg': 'linear-gradient(0deg, #40465F 0%, #61697B 36%, #3D5D77 100%)', // 设备树rgba(40, 75, 104, 1)rgba(100,114,130, 1)'

  '@page-header-bg': 'rgba(61,93,119, 0.5)', // 详情页面顶部信息
  '@layout-body-background': 'rgba(85, 85, 85, 0.0)', // 全局背景
  '@background-color-base': 'rgba(85, 85, 85, 0.2)', // disable复选框
  '@body-background': 'rgba(61,93,119, 1)', // 翻页菜单body
  '@layout-sider-background': 'rgba(19，57，89, 0.5)', // 侧边导航底色
  '@component-background': 'rgba(24,20,35, 0.2)', // dashboard卡片基础背景色
  '@layout-header-background': 'rgba(21,29,60, 0.3)', // 菜单
  '@menu-dark-bg': 'rgba(19,57,89, 0.1)', // 一级菜单
  '@menu-dark-submenu-bg': 'rgba(19,57,89, 0.1)', // 二级菜单
  '@input-bg': 'rgba(48, 74, 98, 0.50)', // 搜索框背景色
  '@btn-default-bg': 'rgba(85, 85, 85, 0.1)', // 次级按钮，实时/历史
  '@border-color-base': 'rgba(139, 138, 151, 0.8)', // 搜索边框61,93,119,
  '@border-color-split': 'rgba(76, 20, 62, 0.2)', // 首页卡片外边框 和  (114,112,128, 0.3)内分割线border-bottom 1px solid rgba();

  '@heading-color': '#E3E3E3',
  '@text-color': 'fade(#FFF, 85%)',
  '@text-color-secondary': 'fade(#FFF, 65%)',

  '@custom-table-tbody-bg': 'rgba(12, 39, 71, 0.2)', // 表格主体背景色
  '@table-selected-row-bg': 'rgba(24,20,35, 0.25)', // 选中表格行，
  '@table-expanded-row-bg': 'rgba(24,20,35, 1)', // 不生效
  '@table-header-bg': 'rgba(45,41,55, 0.2)', // 'rgba(114,112,128, 0.65)',//表格头部
  '@table-row-hover-bg': 'rgba(24,20,35, 0.15)', // 鼠标悬停表格行，

  '@layout-trigger-color': 'fade(#fff, 80%)',
  '@layout-trigger-background': '#313232',

  '@alert-message-color': 'fade(#000, 67%)',
  '@select-dropdown-bg': 'rgba(61,93,119, 1)', // ？？
  '@dropdown-selected-color': 'rgba(61,93,119, 1)',
  '@item-hover-bg': 'fade(#ffffff, 20%)', // ant-dropdown-menu-item-hover
  '@item-active-bg': 'rgba(24,20,35, 0.25)', // 翻页菜单选中

  '@disabled-color': 'rgba(24,20,35, 0.2)', // .ant-pagination-item
  '@tag-default-bg': 'rgba(85, 85, 85, 0.1)',
  '@popover-bg': 'rgba(61,93,119, 1)', // 气泡卡片
  '@wait-icon-color': 'fade(#fff, 64%)', // ？？64%
  '@background-color-light': 'rgba(150, 150, 150, 0.35)', // 翻页菜单悬停
  '@collapse-header-bg': '#fffff', // ？
  '@info-color': '#415964',
  '@primary-color': '#FD9426', // 已改
  '@highlight-color': colors_1.red[7],
  '@warning-color': '#faad14',
  '@shadow-color': 'rgba(0, 0, 0, 0.1)' // 表格右侧固定栏
  // '@box-shadow-base': '0px 2px 3px rgba(0, 0, 0, 0.3)',//没用
  // '@card-shadow': '5px 2px 8px rgba(0, 0, 0, 0.69)'
}
