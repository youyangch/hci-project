<template>
  <a-layout-header style="background: #fff; padding: 0">
    <menu-unfold-outlined
        v-if="collapsed"
        class="trigger"
        @click="() => (collapsed = !collapsed)"
    />
    <menu-fold-outlined v-else class="trigger" @click="() => (collapsed = !collapsed)"/>
  </a-layout-header>
</template>

<script>
import {
  MenuUnfoldOutlined, MenuFoldOutlined,
} from '@ant-design/icons-vue';

export default {
  name: "Header", components: {
    MenuUnfoldOutlined, MenuFoldOutlined
  },
}
</script>

<style scoped>

</style>
