<template>
  <a-layout-sider v-model:collapsed="collapsed" :trigger="null" collapsible>
    <div class="logo"/>
    <a-menu theme="dark" mode="inline" v-model:selectedKeys="selectedKeys">
      <a-menu-item key="1" @click="toAbout">
        <user-outlined/>
        <span>nav 1</span>
      </a-menu-item>
      <a-menu-item key="2" @click="toAbout1">
        <video-camera-outlined/>
        <span>nav 2</span>
      </a-menu-item>
      <a-menu-item key="3">
        <upload-outlined/>
        <span>nav 3</span>
      </a-menu-item>
    </a-menu>
  </a-layout-sider>
</template>

<script>
import {
  UserOutlined, VideoCameraOutlined, UploadOutlined,
} from '@ant-design/icons-vue';

export default {
  name: "SideMenu", components: {
    UserOutlined, VideoCameraOutlined, UploadOutlined,
  }, methods: {
    toAbout() {
      this.$router.push({name: 'About'})
    }, toAbout1() {
      this.$router.push({name: 'About1'})
    }
  }
}
</script>

<style scoped lang="less">
.logo {
  height: 32px;
  background: rgba(255, 255, 255, 0.2);
  margin: 16px;
}
</style>
