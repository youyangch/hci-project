
export default {
    primaryColor: '#1D2742', // primary color of ant design
    navTheme: 'dark', // theme for nav menu
    layout: 'sidemenu', // nav menu position: sidemenu or topmenu
    contentWidth: 'Fixed', // layout of content: Fluid or Fixed, only works when layout is topmenu
    fixedHeader: true, // sticky header
    fixSiderbar: true, // sticky siderbar
    autoHideHeader: true, //  auto hide header
    colorWeak: false,
    multiTab: false,
    production: process.env.NODE_ENV === 'production' && process.env.VUE_APP_PREVIEW !== 'true',
    // vue-ls options
    storageOptions: {
        namespace: 'pro__',
        name: 'ls',
        storage: 'local'
    }
}
