import BasicLayout from "@/layouts/BasicLayout";
import Login from "@/layouts/Login"
import NotFound from "@/layouts/404"

const DynamicRouterMap = [{
    path: '/', component: BasicLayout, redirect: '/index', children: [{
        path: 'index', name: 'About', component: () => import(/* webpackChunkName: "about" */ '@/views/About.vue')
    }, {
        path: 'index', name: 'About1', component: () => import(/* webpackChunkName: "about" */ '@/views/About1.vue')
    }]
}]


export const constantRouterMap = [{
    path: '/login', component: Login, name: "Login",
}, {
    path: '/404', component: NotFound, name: "NotFound",
}, ...DynamicRouterMap]


