<template>
  <a-layout :class="['layout','desktop']">

    <side-menu/>

    <a-layout>

      <Header/>


      <a-layout-content :style="{ margin: '24px 16px', padding: '24px', background: '#fff', minHeight: '280px' }">
        <router-view/>
      </a-layout-content>

      <a-layout-footer style="text-align: center">
        Ant Design ©2018 Created by Ant UED
      </a-layout-footer>
    </a-layout>

  </a-layout>
</template>
<script>
import {mapActions} from 'vuex'
import config from '@/config/defaultSettings'
import SideMenu from '@/components/Menu'
import Header from '@/components/Header'

export default ({
  name: 'BasicLayout', components: {
    SideMenu, Header
  },

  provide() {
    return {
      reload: this.reload
    }
  }, data() {
    return {
      production: config.production, collapsed: false, menus: [],

      // 页面刷新
      isRouterAlive: true
    }
  },

  methods: {
    ...mapActions(['setSidebar']), toggle() {
      this.collapsed = !this.collapsed
      this.setSidebar(!this.collapsed)
      // triggerWindowResizeEvent()
    }, paddingCalc() {
      let left = ''
      if (this.sidebarOpened) {
        left = this.isDesktop() ? '256px' : '80px'
      } else {
        left = (this.isMobile() && '0') || ((this.fixSidebar && '80px') || '0')
      }
      return left
    }, menuSelect() {
      if (!this.isDesktop()) {
        this.collapsed = false
      }
    }, drawerClose() {
      this.collapsed = false
    },

    // 页面刷新
    reload() {
      this.isRouterAlive = false
      this.$nextTick(function () {
        this.isRouterAlive = true
      })
    }
  }

});
</script>
<style lang="less">
@import url('../components/global.less');

/*
 * The following styles are auto-applied to elements with
 * transition="page-transition" when their visibility is toggled
 * by Vue.js.
 *
 * You can easily play with the page transition by editing
 * these styles.
 */

.page-transition-enter {
  opacity: 0;
}

.page-transition-leave-active {
  opacity: 0;
}

.page-transition-enter .page-transition-container,
.page-transition-leave-active .page-transition-container {
  -webkit-transform: scale(1.1);
  transform: scale(1.1);
}
</style>

