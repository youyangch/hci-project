<template>
  <div class="about">
    <h1>This is an about1 page</h1>
  </div>
</template>
